﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using OnlineBakeryStore;

namespace OnlineBakeryStore.Controllers
{
    public class DepartmentController : ApiController
    {
        private BakeryStoreDBEntities db = new BakeryStoreDBEntities();

        // GET: api/Department
        public IQueryable<tbl_Department> Gettbl_Department()
        {
            return db.tbl_Department;
           // return db.tbl_Department.Include(t => t.tbl_Location);
        }

        // GET: api/Department/5
        [ResponseType(typeof(tbl_Department))]
        public IHttpActionResult Gettbl_Department(int id)
        {
            tbl_Department tbl_Department = db.tbl_Department.Find(id);
            if (tbl_Department == null)
            {
                return NotFound();
            }

            return Ok(tbl_Department);
        }

        // PUT: api/Department/5
        [ResponseType(typeof(void))]
        public IHttpActionResult Puttbl_Department(int id, tbl_Department tbl_Department)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != tbl_Department.DeptId)
            {
                return BadRequest();
            }

            db.Entry(tbl_Department).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!tbl_DepartmentExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/Department
        [ResponseType(typeof(tbl_Department))]
        public IHttpActionResult Posttbl_Department(tbl_Department tbl_Department)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.tbl_Department.Add(tbl_Department);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = tbl_Department.DeptId }, tbl_Department);
        }

        // DELETE: api/Department/5
        [ResponseType(typeof(tbl_Department))]
        public IHttpActionResult Deletetbl_Department(int id)
        {
            tbl_Department tbl_Department = db.tbl_Department.Find(id);
            if (tbl_Department == null)
            {
                return NotFound();
            }

            db.tbl_Department.Remove(tbl_Department);
            db.SaveChanges();

            return Ok(tbl_Department);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool tbl_DepartmentExists(int id)
        {
            return db.tbl_Department.Count(e => e.DeptId == id) > 0;
        }
    }
}