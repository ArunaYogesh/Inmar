﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using OnlineBakeryStore;

namespace OnlineBakeryStore.Controllers
{
    public class DepartmentNamesController : ApiController
    {
        private BakeryStoreDBEntities db = new BakeryStoreDBEntities();

        // GET: api/DepartmentNames
        public IQueryable<DepartmentName> GetDepartmentNames()
        {
            return db.DepartmentNames;
        }

        // GET: api/DepartmentNames/5
        [ResponseType(typeof(DepartmentName))]
        public IHttpActionResult GetDepartmentName(int id)
        {
            DepartmentName departmentName = db.DepartmentNames.Find(id);
            if (departmentName == null)
            {
                return NotFound();
            }

            return Ok(departmentName);
        }

        // PUT: api/DepartmentNames/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutDepartmentName(int id, DepartmentName departmentName)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != departmentName.DeptId)
            {
                return BadRequest();
            }

            db.Entry(departmentName).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!DepartmentNameExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/DepartmentNames
        [ResponseType(typeof(DepartmentName))]
        public IHttpActionResult PostDepartmentName(DepartmentName departmentName)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.DepartmentNames.Add(departmentName);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = departmentName.DeptId }, departmentName);
        }

        // DELETE: api/DepartmentNames/5
        [ResponseType(typeof(DepartmentName))]
        public IHttpActionResult DeleteDepartmentName(int id)
        {
            DepartmentName departmentName = db.DepartmentNames.Find(id);
            if (departmentName == null)
            {
                return NotFound();
            }

            db.DepartmentNames.Remove(departmentName);
            db.SaveChanges();

            return Ok(departmentName);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool DepartmentNameExists(int id)
        {
            return db.DepartmentNames.Count(e => e.DeptId == id) > 0;
        }
    }
}