﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using OnlineBakeryStore;

namespace OnlineBakeryStore.Controllers
{
    public class SubCategoryController : ApiController
    {
        private BakeryStoreDBEntities db = new BakeryStoreDBEntities();

        // GET: api/SubCategory
        public IQueryable<tbl_SubCategory> Gettbl_SubCategory()
        {
            return db.tbl_SubCategory;
        }

        // GET: api/SubCategory/5
        [ResponseType(typeof(tbl_SubCategory))]
        public IHttpActionResult Gettbl_SubCategory(int id)
        {
            tbl_SubCategory tbl_SubCategory = db.tbl_SubCategory.Find(id);
            if (tbl_SubCategory == null)
            {
                return NotFound();
            }

            return Ok(tbl_SubCategory);
        }

        // PUT: api/SubCategory/5
        [ResponseType(typeof(void))]
        public IHttpActionResult Puttbl_SubCategory(int id, tbl_SubCategory tbl_SubCategory)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != tbl_SubCategory.SubCatgId)
            {
                return BadRequest();
            }

            db.Entry(tbl_SubCategory).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!tbl_SubCategoryExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/SubCategory
        [ResponseType(typeof(tbl_SubCategory))]
        public IHttpActionResult Posttbl_SubCategory(tbl_SubCategory tbl_SubCategory)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.tbl_SubCategory.Add(tbl_SubCategory);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = tbl_SubCategory.SubCatgId }, tbl_SubCategory);
        }

        // DELETE: api/SubCategory/5
        [ResponseType(typeof(tbl_SubCategory))]
        public IHttpActionResult Deletetbl_SubCategory(int id)
        {
            tbl_SubCategory tbl_SubCategory = db.tbl_SubCategory.Find(id);
            if (tbl_SubCategory == null)
            {
                return NotFound();
            }

            db.tbl_SubCategory.Remove(tbl_SubCategory);
            db.SaveChanges();

            return Ok(tbl_SubCategory);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool tbl_SubCategoryExists(int id)
        {
            return db.tbl_SubCategory.Count(e => e.SubCatgId == id) > 0;
        }
    }
}