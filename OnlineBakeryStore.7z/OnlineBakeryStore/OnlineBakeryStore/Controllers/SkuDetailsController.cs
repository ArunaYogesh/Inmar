﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using OnlineBakeryStore;
using OnlineBakeryStore.Models;

namespace OnlineBakeryStore.Controllers
{
   // [RoutePrefix("api/SkuDetails")]
    public class SkuDetailsController : ApiController
    {
        private BakeryStoreDBEntities db = new BakeryStoreDBEntities();

        // GET: api/SkuDetails
        //public IQueryable<tbl_SkuDetails> Gettbl_SkuDetails()
        //{
        //    return db.tbl_SkuDetails;
        //}

        // GET: api/SkuDetails/5
        [ResponseType(typeof(tbl_SkuDetails))]
        public IHttpActionResult Gettbl_SkuDetails(int id)
        {
            tbl_SkuDetails tbl_SkuDetails = db.tbl_SkuDetails.Find(id);
            if (tbl_SkuDetails == null)
            {
                return NotFound();
            }

            return Ok(tbl_SkuDetails);
        }

        //[Route("getalldetails")]
        [HttpGet]
        [ResponseType(typeof(SkuWeb))]
        public IHttpActionResult GetAllDetails()
        {
            var skuData = from sku in db.tbl_SkuDetails
                          join scd in db.tbl_SubCategory
                          on sku.SubCatgId equals scd.SubCatgId
                          join c in db.tbl_Category
                          on scd.CatgId equals c.CatgId
                          join d in db.tbl_Department
                          on c.DeptId equals d.DeptId
                          join l in db.tbl_Location
                          on d.LocId equals l.LocId
                          //where l.LocId == locID
                          //where d.DeptId == deptId
                          //where c.CatgId == catgId
                          select new SkuWeb
                          {
                              SkuId = sku.SKUId,
                              SkuName = sku.SKUName,
                              LocName = l.LocName,
                              DeptName = d.DeptName,
                              CatgName = c.CatgName,
                              SubCatgName = scd.SubCatgName
                          };

            if (skuData != null)
            {
                return Ok(skuData);
            }
            return null;
        }

       

        // PUT: api/SkuDetails/5
        [ResponseType(typeof(void))]
        public IHttpActionResult Puttbl_SkuDetails(int id, tbl_SkuDetails tbl_SkuDetails)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != tbl_SkuDetails.SKUId)
            {
                return BadRequest();
            }

            db.Entry(tbl_SkuDetails).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!tbl_SkuDetailsExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/SkuDetails
        [ResponseType(typeof(tbl_SkuDetails))]
        public IHttpActionResult Posttbl_SkuDetails(tbl_SkuDetails tbl_SkuDetails)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.tbl_SkuDetails.Add(tbl_SkuDetails);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = tbl_SkuDetails.SKUId }, tbl_SkuDetails);
        }

        // DELETE: api/SkuDetails/5
        [ResponseType(typeof(tbl_SkuDetails))]
        public IHttpActionResult Deletetbl_SkuDetails(int id)
        {
            tbl_SkuDetails tbl_SkuDetails = db.tbl_SkuDetails.Find(id);
            if (tbl_SkuDetails == null)
            {
                return NotFound();
            }

            db.tbl_SkuDetails.Remove(tbl_SkuDetails);
            db.SaveChanges();

            return Ok(tbl_SkuDetails);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool tbl_SkuDetailsExists(int id)
        {
            return db.tbl_SkuDetails.Count(e => e.SKUId == id) > 0;
        }
    }
}