﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using OnlineBakeryStore;

namespace OnlineBakeryStore.Controllers
{
    public class LocationNamesController : ApiController
    {
        private BakeryStoreDBEntities db = new BakeryStoreDBEntities();

        // GET: api/LocationNames
        public IQueryable<LocationName> GetLocationNames()
        {
            return db.LocationNames;
        }

        // GET: api/LocationNames/5
        [ResponseType(typeof(LocationName))]
        public IHttpActionResult GetLocationName(int id)
        {
            LocationName locationName = db.LocationNames.Find(id);
            if (locationName == null)
            {
                return NotFound();
            }

            return Ok(locationName);
        }

        // PUT: api/LocationNames/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutLocationName(int id, LocationName locationName)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != locationName.LocId)
            {
                return BadRequest();
            }

            db.Entry(locationName).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!LocationNameExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/LocationNames
        [ResponseType(typeof(LocationName))]
        public IHttpActionResult PostLocationName(LocationName locationName)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.LocationNames.Add(locationName);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = locationName.LocId }, locationName);
        }

        // DELETE: api/LocationNames/5
        [ResponseType(typeof(LocationName))]
        public IHttpActionResult DeleteLocationName(int id)
        {
            LocationName locationName = db.LocationNames.Find(id);
            if (locationName == null)
            {
                return NotFound();
            }

            db.LocationNames.Remove(locationName);
            db.SaveChanges();

            return Ok(locationName);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool LocationNameExists(int id)
        {
            return db.LocationNames.Count(e => e.LocId == id) > 0;
        }
    }
}