﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using OnlineBakeryStore;
using OnlineBakeryStore.Models;

namespace OnlineBakeryStore.Controllers
{
    [RoutePrefix("api/SearchData")]
    public class SearchDataController : ApiController
    {
        private BakeryStoreDBEntities db = new BakeryStoreDBEntities();

        //// GET: api/SearchData
        //public IQueryable<tbl_Role> Gettbl_Role()
        //{
        //    return db.tbl_Role;
        //}

        //// GET: api/SearchData/5
        //[ResponseType(typeof(tbl_Role))]
        //public IHttpActionResult Gettbl_Role(int id)
        //{
        //    tbl_Role tbl_Role = db.tbl_Role.Find(id);
        //    if (tbl_Role == null)
        //    {
        //        return NotFound();
        //    }

        //    return Ok(tbl_Role);
        //}

        //// PUT: api/SearchData/5
        //[ResponseType(typeof(void))]
        //public IHttpActionResult Puttbl_Role(int id, tbl_Role tbl_Role)
        //{
        //    if (!ModelState.IsValid)
        //    {
        //        return BadRequest(ModelState);
        //    }

        //    if (id != tbl_Role.RoleId)
        //    {
        //        return BadRequest();
        //    }

        //    db.Entry(tbl_Role).State = EntityState.Modified;

        //    try
        //    {
        //        db.SaveChanges();
        //    }
        //    catch (DbUpdateConcurrencyException)
        //    {
        //        if (!tbl_RoleExists(id))
        //        {
        //            return NotFound();
        //        }
        //        else
        //        {
        //            throw;
        //        }
        //    }

        //    return StatusCode(HttpStatusCode.NoContent);
        //}

        //// POST: api/SearchData
        //[ResponseType(typeof(tbl_Role))]
        //public IHttpActionResult Posttbl_Role(tbl_Role tbl_Role)
        //{
        //    if (!ModelState.IsValid)
        //    {
        //        return BadRequest(ModelState);
        //    }

        //    db.tbl_Role.Add(tbl_Role);
        //    db.SaveChanges();

        //    return CreatedAtRoute("DefaultApi", new { id = tbl_Role.RoleId }, tbl_Role);
        //}

        //// DELETE: api/SearchData/5
        //[ResponseType(typeof(tbl_Role))]
        //public IHttpActionResult Deletetbl_Role(int id)
        //{
        //    tbl_Role tbl_Role = db.tbl_Role.Find(id);
        //    if (tbl_Role == null)
        //    {
        //        return NotFound();
        //    }

        //    db.tbl_Role.Remove(tbl_Role);
        //    db.SaveChanges();

        //    return Ok(tbl_Role);
        //}

        //protected override void Dispose(bool disposing)
        //{
        //    if (disposing)
        //    {
        //        db.Dispose();
        //    }
        //    base.Dispose(disposing);
        //}

        //private bool tbl_RoleExists(int id)
        //{
        //    return db.tbl_Role.Count(e => e.RoleId == id) > 0;
        //}


        [Route("{id:int}/Department")]
        [HttpGet]
        //[Route("location/{customerId}/department")]
        [ResponseType(typeof(DeptDetails))]
        public IHttpActionResult LocationDepartment(int id)
        {
            var dept = from d in db.tbl_Department.Include(l => l.tbl_Location)
                       where d.LocId == id
                       select new DeptDetails { DeptId = d.DeptId, DeptName = d.DeptName, LocName = d.tbl_Location.LocName };
            if (dept != null)
            {
                return Ok(dept);
            }


            return null;
        }

        [Route("{deptId:int}/category")]
        [HttpGet]
        //[Route("location/{customerId}/department")]
        [ResponseType(typeof(CatgDetails))]
        public IHttpActionResult LocationDepartmentCateg(int deptId)
        {
            //var catg = from l in db.tbl_Location
            //           join d in db.tbl_Department
            //           on l.LocId equals d.LocId
            //           join c in db.tbl_Category
            //           on d.DeptId equals c.DeptId
            //           where l.LocId == locID 
            //           where d.DeptId == deptId 
            //           select new CatgDetails { CatgId = c.CatgId, CatgName= c.CatgName, DeptName = d.DeptName, LocName = l.LocName };

            var catg = from c in db.tbl_Category.Include(d => d.tbl_Department)
                       where c.DeptId == deptId
                       select new CatgDetails { CatgId = c.CatgId, CatgName = c.CatgName, DeptName = c.tbl_Department.DeptName };

            if (catg != null)
            {
                return Ok(catg);
            }
            return null;
        }

        //[Route("{locID:int}/Department/{deptId:int}/category/{catgId:int}/subcategory")]
        [Route("{catgId:int}/subcategory")]
        [HttpGet]
        //[Route("location/{customerId}/department")]
        [ResponseType(typeof(SubCatg))]
        public IHttpActionResult LocDeptCatgSubCatg(int catgId)
        {
            //var subcatg = from l in db.tbl_Location
            //              join d in db.tbl_Department
            //              on l.LocId equals d.LocId
            //              join c in db.tbl_Category
            //              on d.DeptId equals c.DeptId
            //              join s in db.tbl_SubCategory
            //              on c.CatgId equals s.CatgId
            //              where l.LocId == locID
            //              where d.DeptId == deptId
            //              where c.CatgId == catgId
            //              select new SubCatg
            //              {
            //                  SubCatgId = s.SubCatgId,
            //                  SubCatgName = s.SubCatgName,
            //                  CatgName = c.CatgName,
            //                  DeptName = d.DeptName,
            //                  LocName = l.LocName
            //              };


            var subcatg = from sc in db.tbl_SubCategory.Include(c => c.tbl_Category)
                          where sc.CatgId == catgId
                          select new SubCatg { SubCatgId = sc.SubCatgId, SubCatgName = sc.SubCatgName, CatgName = sc.tbl_Category.CatgName };


            if (subcatg != null)
            {
                return Ok(subcatg);
            }
            return null;
        }

        [Route("{locId:int}/department/{deptId:int}/catg/{catgId:int}/subcatg/{subId:int}")]
        [HttpGet]
        [ResponseType(typeof(SkuWeb))]
        public IHttpActionResult SearchById(int locId, int deptId, int catgId, int subId)
        {
            var skuData = from sku in db.tbl_SkuDetails
                          join scd in db.tbl_SubCategory
                          on sku.SubCatgId equals scd.SubCatgId
                          join c in db.tbl_Category
                          on scd.CatgId equals c.CatgId
                          join d in db.tbl_Department
                          on c.DeptId equals d.DeptId
                          join l in db.tbl_Location
                          on d.LocId equals l.LocId
                          where scd.SubCatgId == subId
                          where c.CatgId == catgId
                          where d.DeptId == deptId
                          where l.LocId == locId
                          select new SkuWeb
                          {
                              SkuId = sku.SKUId,
                              SkuName = sku.SKUName,
                              LocName = l.LocName,
                              DeptName = d.DeptName,
                              CatgName = c.CatgName,
                              SubCatgName = scd.SubCatgName
                          };

            if (skuData != null)
            {
                return Ok(skuData);
            }
            return null;
        }

    }
}