﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OnlineBakeryStore.Models
{
    public class DeptDetails
    {
        public int DeptId { get; set; }
        public string DeptName { get; set; }

        public string LocName { get; set; }
    }
}