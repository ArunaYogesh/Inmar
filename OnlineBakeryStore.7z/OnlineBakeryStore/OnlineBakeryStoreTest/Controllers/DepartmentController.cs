﻿using OnlineBakeryStoreTest.Models;
using OnlineBakeryStoreTest.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;

namespace OnlineBakeryStoreTest.Controllers
{
    public class DepartmentController : Controller
    {
        // GET: Department
        public ActionResult Index()
        {
            DepartmentsClient DC = new DepartmentsClient();
            var dept = DC.findAll().ToList();

            LocationsClient LC = new LocationsClient();
            var loc = LC.findAll().ToList();

            if (dept != null && loc != null)
            {
                var linqDept = (from e in dept
                                join d in loc on e.LocId equals d.LocId
                                select new MyDept
                                { DeptId = e.DeptId, DeptName = e.DeptName, LocName = d.LocName });
                ViewBag.listDepartment = linqDept;
            }
            if (dept == null)
            {
                ViewBag.ErrorMessage = "No records found.";
            }
            return View();
        }

        public ActionResult Details(int id)
        {
            if (id.Equals(null))
            {
                // return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                ViewBag.ErrorMessage = "Record not found";
                View("index");
            }
            DepartmentsClient DC = new DepartmentsClient();
            DepartmentsViewModel DVM = new DepartmentsViewModel();
            LocationsClient LC = new LocationsClient();
            DVM.department = DC.find(id);
            if (DVM.department == null)
            {
                return HttpNotFound();
            }
            var locName = LC.findAll().Where(x => x.LocId == DVM.department.DeptId).Select(v => v.LocName);
            if (locName != null)
            {
                foreach (var l in locName)
                {
                    ViewBag.LocName =l.ToString();
                }
            }
            return View(DVM.department);
        }

        [HttpGet]
        public ActionResult Create()
        {
            LocationsClient LC = new LocationsClient();
            //ViewBag.listLocationNames = LC.GetLocationNames();
            ViewBag.dropdownVD = new SelectList(LC.findAll().ToList(), "locId", "locName");
            return View();
        }

        [HttpPost]
        public ActionResult Create(DepartmentsViewModel dept,FormCollection form)
        {
            bool bCreate = false;
            DepartmentsClient dc = new DepartmentsClient();
            dept.department.LocId = Convert.ToInt32(form["dropdownVD"]);
            bCreate = dc.Create(dept.department);
            if (!bCreate)
            {
                ViewBag.ErrorMessage = "Record not saved.";
                return View("create");
            }
            return RedirectToAction("index");
        }

       // [HttpDelete]
        public ActionResult Delete(int id)
        {
            bool bDelete = false;
            DepartmentsClient DC = new DepartmentsClient();
            bDelete= DC.Delete(id);
            if (!bDelete)
            {
                ViewBag.ErrorMessage = "Record not deleted";
               
            }
            return RedirectToAction("Index");
        }

        [HttpGet]
        public ActionResult Edit(int id)
        {
            if (id.Equals(null))
            {
                ViewBag.ErrorMessage = "Not valid data";
                return RedirectToAction("index");
                //return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            LocationsClient LC = new LocationsClient();
            DepartmentsClient DC = new DepartmentsClient();
            DepartmentsViewModel DVM = new DepartmentsViewModel();
            DVM.department = DC.find(id);
            if (DVM.department == null)
            {
                return HttpNotFound();
            }
            ViewBag.LocId = new SelectList(LC.findAll().ToList(), "LocId", "LocName", DVM.department.LocId);
            return View("Edit", DVM);
        }
        [HttpPost]
        public ActionResult Edit(DepartmentsViewModel DVM,FormCollection form)
        {
            bool bEdit = false;
            DepartmentsClient DC = new DepartmentsClient();
            DVM.department.LocId = Convert.ToInt32(form["LocId"]);
            bEdit =  DC.Edit(DVM.department);
            if (!bEdit)
            {
                ViewBag.ErrorMessage = "Record not updated.";
                return View("edit");
            }
            return RedirectToAction("Index");
        }
    }
}