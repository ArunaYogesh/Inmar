﻿using OnlineBakeryStoreTest.Models;
using OnlineBakeryStoreTest.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;

namespace OnlineBakeryStoreTest.Controllers
{
    //[Authorize]
    public class LocationController : Controller
    {
        // GET: Location
        public ActionResult Index()
        {
            LocationsClient LC = new LocationsClient();
            ViewBag.listLocations = LC.findAll();
            if (ViewBag.listLocations == null)
            {
                ViewBag.ErrorMessage = "No Records found.";
                return View("index");
            }
            return View(LC);
        }

        public ActionResult GetDepartmentByLoc(int id)
        {
            LocationsClient LC = new LocationsClient();
            ViewBag.listDepartment = LC.GetDepartmentsByLoc(id);

            //return RedirectToAction("department/index");
            return View("GetDepartmentByLoc");
        }

        public ActionResult CatgDeptLoc(int deptId)
        {
            LocationsClient LC = new LocationsClient();
            ViewBag.listCatg = LC.CatgDeptLoc(deptId);

            //return RedirectToAction("department/index");
            return View("CatgDeptLoc");
        }

        //public ActionResult SubCatgDeptLoc(int locId,int deptId,int catgId)
        //{
        //    LocationsClient LC = new LocationsClient();
        //    ViewBag.listSubCatg = LC.SubCatgDeptLoc(locId,deptId,catgId);

        //    //return RedirectToAction("department/index");
        //    return View("SubCatgDeptLoc");
        //}

        public ActionResult SKUData()
        {

            return View();
        }

        public ActionResult Details(int id)
        {
            if (id.Equals(null))
            {
                ViewBag.ErrorMessage = "No records found with the search";
                return View();
                // return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
           
            LocationsViewModel LVM = new LocationsViewModel();
            LocationsClient LC = new LocationsClient();
            LVM.locations = LC.find(id);
            if (LVM.locations == null)
            {
                ViewBag.ErrorMessage = "No Records found.";
                return View("index");
            }
          
            return View(LVM.locations);
        }
        //Get: Location
        [HttpGet]
        public ActionResult Create()
        {
            LocationsClient LC = new LocationsClient();
            ViewBag.listLocationNames =  LC.GetLocationNames();
          
            return View();
        }

        //Post: Location
        [HttpPost]
        public ActionResult Create(LocationsViewModel location)
        {
            bool bCreate = false;
            LocationsClient LC = new LocationsClient();
            bCreate = LC.Create(location.locations);
            if (!bCreate)
            {
                ViewBag.ErrorMessage = "Record not created.";
                return View("Create");
            }

            return RedirectToAction("index");
        }

        //[HttpDelete]
        public ActionResult Delete(int id)
        {
            bool bDelete = false;
            if (id.Equals(null))
            {
                ViewBag.ErrorMessage = "Error deleting the Record.";
            }
            LocationsClient LC = new LocationsClient();
            bDelete = LC.Delete(id);
            if (!bDelete)
            {
                ViewBag.ErrorMessage = "Record not deleted.";
            }
            return RedirectToAction("Index");
        }

        [HttpGet]
        public ActionResult Edit(int id)
        {
            LocationsClient LC = new LocationsClient();
            LocationsViewModel LVM = new LocationsViewModel();
            LVM.locations = LC.find(id);
            if (LVM.locations != null)
            {
                ViewBag.ErrorMessage = "No record found";
                //return View("edit", LVM);
            }
            return View("edit", LVM);
            //return RedirectToAction("index");
        }
        [HttpPost]
        public ActionResult Edit(LocationsViewModel LVM)
        {
            bool bEdit = false;
            LocationsClient CC = new LocationsClient();
            bEdit = CC.Edit(LVM.locations);
            if (!bEdit)
            {
                ViewBag.ErrorMessage = "Record not updated.";
                return View("edit");
            }
            return RedirectToAction("Index");
        }
    }
}