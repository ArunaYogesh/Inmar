﻿using OnlineBakeryStoreTest.Models;
using OnlineBakeryStoreTest.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;

namespace OnlineBakeryStoreTest.Controllers
{
    public class SubCategoryController : Controller
    {
        // GET: SubCategory
        public ActionResult Index()
        {
            SubCategoryClient SC = new SubCategoryClient();
            var subcatg = SC.findAll().ToList();

            CategoryClient CC = new CategoryClient();
            var catg = CC.findAll().ToList();
            if (subcatg != null && catg != null)
            {
                var linqSubCatg = (from s in subcatg
                                   join c in catg on s.CatgId equals c.CatgId
                                   select new MySubCatg
                                   { SubCatgId = s.SubCatgId, SubCatgName = s.SubCatgName, CatgName = c.CatgName });
                ViewBag.listSubCategory = linqSubCatg;
            }
            if (subcatg == null )
            {
                ViewBag.ErrorMessage = "No records found";
            }
            return View();
        }
        public ActionResult Details(int id)
        {
            if (id.Equals(null))
            {
                ViewBag.ErrorMessage = "No records found with the search.";
                return View();
                // return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            SubCategoryClient SC = new SubCategoryClient();
            SubCategoryViewModel SVM = new SubCategoryViewModel();
            CategoryClient CC = new CategoryClient();
            SVM.subCategory = SC.find(id);
            if (SVM.subCategory == null)
            {
                ViewBag.ErrorMessage = "No records found";
                return View();
            }
            var catgName = CC.findAll().Where(x => x.CatgId == SVM.subCategory.CatgId).Select(v => v.CatgName);
            if (catgName != null)
            {
                foreach (var c in catgName)
                {
                    ViewBag.CatgName = c.ToString();
                }
            }
            return View(SVM.subCategory);
        }

        [HttpGet]
        public ActionResult Create()
        {
            CategoryClient CC = new CategoryClient();
            //ViewBag.listLocationNames = LC.GetLocationNames();
            ViewBag.dropdownlist = new SelectList(CC.findAll().ToList(), "catgId", "catgName");
            return View();
        }

        [HttpPost]
        public ActionResult Create(SubCategoryViewModel subcatg, FormCollection form)
        {
            bool bCreate = false;
            SubCategoryClient SC = new SubCategoryClient();
            subcatg.subCategory.CatgId = Convert.ToInt32(form["dropdownlist"]);
            bCreate = SC.Create(subcatg.subCategory);
            if (!bCreate)
            {
                ViewBag.ErrorMessage = "Records not saved.";
                return View("create");
            }
            //else
            //{ ViewBag.ErrorMessage = "Records  saved."; }

            //return View("create");
            return RedirectToAction("index");
        }

        //[HttpDelete]
        public ActionResult Delete(int id)
        {
            bool bDelete = false;
            if (id.Equals(null))
            {
                ViewBag.ErrorMessage = "Error deleting the record.";
                //return View();
                // new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            SubCategoryClient SC = new SubCategoryClient();
            bDelete = SC.Delete(id);

            if (bDelete == false)
            {
                ViewBag.ErrorMessage = "Error deleting the record.";
               // return View();
            }
            return RedirectToAction("Index");
        }

        [HttpGet]
        public ActionResult Edit(int id)
        {
            if (id.Equals(null))
            {
                ViewBag.ErrorMessage = "No records found with the search";
                RedirectToAction("Index");
                //return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            SubCategoryClient SC = new SubCategoryClient();
            CategoryClient CC = new CategoryClient();
            SubCategoryViewModel SVM = new SubCategoryViewModel();
            SVM.subCategory = SC.find(id);
            if (SVM.subCategory == null)
            {
                return HttpNotFound();
            }
            ViewBag.CatgId = new SelectList(CC.findAll().ToList(), "catgId", "catgName", SVM.subCategory.CatgId);
            return View("Edit", SVM);
        }

        [HttpPost]
        public ActionResult Edit(SubCategoryViewModel SVM, FormCollection form)
        {
            bool bUpdate = false;
            SubCategoryClient SC = new SubCategoryClient();
            SVM.subCategory.CatgId = Convert.ToInt32(form["CatgId"]);
            bUpdate = SC.Edit(SVM.subCategory);
            if (!bUpdate)
            {
                ViewBag.ErrorMessage = "Record not updated.";
                return View("edit");
            }
            return RedirectToAction("Index");
        }



    }
}