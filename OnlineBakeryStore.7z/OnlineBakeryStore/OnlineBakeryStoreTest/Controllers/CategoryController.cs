﻿using OnlineBakeryStoreTest.Models;
using OnlineBakeryStoreTest.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;

namespace OnlineBakeryStoreTest.Controllers
{
    public class CategoryController : Controller
    {
        // GET: Category
        public ActionResult Index()
        {
            CategoryClient CC = new CategoryClient();
            var catg = CC.findAll().ToList();

            DepartmentsClient DC = new DepartmentsClient();
            var dept = DC.findAll().ToList();

            if (catg != null && dept != null)
            {
                var linqCatg = (from c in catg
                                join d in dept on c.DeptId equals d.DeptId
                                select new MyCatg
                                { CatgId = c.CatgId, CatgName = c.CatgName, DeptName = d.DeptName });

                ViewBag.listCategory = linqCatg;
            }
            if (catg == null)
            {
                ViewBag.ErrorMessage = "No records found.";
            }
            return View();
        }

        public ActionResult Details(int id)
        {
            if (id.Equals(null))
            {
                ViewBag.ErrorMessage = "Not valid data";
                View("index");
                // return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            DepartmentsClient DC = new DepartmentsClient();
            CategoryViewModel CVM = new CategoryViewModel();
            CategoryClient CC = new CategoryClient();
            CVM.category = CC.find(id);
            if (CVM.category == null)
            {
                return HttpNotFound();
            }

            var deptName = DC.findAll().Where(x => x.DeptId == CVM.category.DeptId).Select(v => v.DeptName);

            if (deptName != null)
            {
                foreach (var c in deptName)
                {
                    ViewBag.DeptName = c.ToString();
                }
            }
           // ViewBag.DetailsDeptId = new SelectList(DC.findAll().ToList(), "deptId", "deptName", CVM.category.DeptId);
            return View(CVM.category);
        }


        [HttpGet]
        public ActionResult Create()
        {
            DepartmentsClient DC = new DepartmentsClient();
            //ViewBag.listLocationNames = LC.GetLocationNames();
            ViewBag.dropdownlist = new SelectList(DC.findAll().ToList(), "deptId", "deptName");
            return View();
        }

        [HttpPost]
        public ActionResult Create(CategoryViewModel catg, FormCollection form)
        {
            bool bCreate = false;
            CategoryClient cc = new CategoryClient();
            catg.category.DeptId = Convert.ToInt32(form["dropdownlist"]);
            bCreate = cc.Create(catg.category);
            if (!bCreate)
            {
                ViewBag.ErrorMessage = "Record not saved.";
                View("Create");
            }
            return RedirectToAction("index");
        }


       // [HttpDelete]
        public ActionResult Delete(int id)
        {
            bool bDelete = false;
            if (id.Equals(null))
            {
                ViewBag.ErrorMessage = "Not valid data";
                View("Index");
                // return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            CategoryClient CC = new CategoryClient();
            bDelete = CC.Delete(id);

            if (bDelete == false)
            {
                ViewBag.ErrorMessage = "Record not deleted.";
               
                // return HttpNotFound();
            }
            return RedirectToAction("Index");
        }

        [HttpGet]
        public ActionResult Edit(int id)
        {
            if (id.Equals(null))
            {
                ViewBag.ErrorMessage = "Not valid data";
                View("index");
                // return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            DepartmentsClient DC = new DepartmentsClient();
            CategoryClient CC = new CategoryClient();
            CategoryViewModel CVM = new CategoryViewModel();
            CVM.category = CC.find(id);
            if (CVM.category == null)
            {
                return HttpNotFound();
            }
            ViewBag.DeptId = new SelectList(DC.findAll().ToList(), "deptId", "deptName", CVM.category.DeptId);
            return View("Edit", CVM);
        }
        [HttpPost]
        public ActionResult Edit(CategoryViewModel CVM, FormCollection form)
        {
            bool bEdit = false;
            CategoryClient CC = new CategoryClient();
            CVM.category.DeptId = Convert.ToInt32(form["DeptId"]);
            bEdit = CC.Edit(CVM.category);
            if (!bEdit)
            {
                ViewBag.ErrorMessage = "Record not upated.";
                View("edit");
            }
            return RedirectToAction("Index");
        }
    }
}