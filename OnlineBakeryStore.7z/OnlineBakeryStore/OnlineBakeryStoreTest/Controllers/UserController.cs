﻿using OnlineBakeryStoreTest.Models;
using OnlineBakeryStoreTest.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace OnlineBakeryStoreTest.Controllers
{
    public class UserController : Controller
    {
        // GET: User

        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        //[ValidateAntiForgeryToken]
        public ActionResult Index(UsersViewModel userView)
        {
            UsersClient UC = new UsersClient();

            Users user = UC.find(userView.users.username);

            if (userView.users.password == user.password)
            {
                Session["UserID"] = user.UserID.ToString();
                Session["UserName"] = user.username.ToString();
                return RedirectToAction("index","home");
            }
            else
            {
                ViewBag.ErrorMessage = "Invalid credentials.";
                Session["UserID"] = null;
                Session["UserName"] = null;
            }
            return View(userView);
        }

        [HttpGet]
        public ActionResult Register()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Register(UsersViewModel usv)
        {
            bool bCreate = false;
            Session["UserID"] = null;
            Session["UserName"] = null;

            UsersClient UC = new UsersClient();

            bCreate = UC.Create(usv.users);
            if (!bCreate)
            {
                ViewBag.ErrorMessage = "Records not saved.";
                return View("create");
            }
            else
            {
                ViewBag.ErrorMessage = "Records  saved.";
            }
            //else
            return View();

        }

        public ActionResult Logout()
        {
            Session["UserID"] = null;
            Session["UserName"] = null;
            return RedirectToAction("index", "home");
        }
        public ActionResult UserDashBoard()
        {
            if (Session["UserID"] != null)
            {
                return View();
            }
            else
            {
                return RedirectToAction("index");
            }
        }
    }
}