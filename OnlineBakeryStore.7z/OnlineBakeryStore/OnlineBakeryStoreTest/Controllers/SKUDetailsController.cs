﻿using OnlineBakeryStoreTest.Models;
using OnlineBakeryStoreTest.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace OnlineBakeryStoreTest.Controllers
{
    public class SKUDetailsController : Controller
    {
        // GET: SKUDetails
        //public ActionResult Index()
        //{
        //    return View();
        //}

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }

        [HttpGet]
        public ActionResult Create()
        {
            LocationsClient LC = new LocationsClient();
            var loc = LC.findAll().ToList();
            List<SelectListItem> liLoc = new List<SelectListItem>();
            liLoc.Add(new SelectListItem { Text = "--Select Location--", Value = "0" });

            foreach (var m in loc)
            {
                liLoc.Add(new SelectListItem { Text = m.LocName, Value = m.LocId.ToString() });
                ViewBag.Location = liLoc;
            }
            return View();
        }

        [HttpPost]
        public ActionResult Create(SkuViewModel skuVM, FormCollection form)
        {
            bool bCreate = false;
            SkuClient skc = new SkuClient();
            skuVM.skuDat.LocId = Convert.ToInt32(form["Location"]);
            skuVM.skuDat.DeptId = Convert.ToInt32(form["Dept"]);
            skuVM.skuDat.CatgId = Convert.ToInt32(form["Catg"]);
            skuVM.skuDat.SubCatgID = Convert.ToInt32(form["SubCatg"]);
            bCreate = skc.Create(skuVM.skuDat);
            if (!bCreate)
            {
                ViewBag.ErrorMessage = "Records not saved.";
                return View("create");
            }
            return RedirectToAction("index");
        }

        public ActionResult Index()
        {
            SkuClient SC = new SkuClient();

            ViewBag.listSku = SC.GetAll().ToList();
            
            if (ViewBag.listSku == null)
            {
                ViewBag.ErrorMessage = "No records found";
                return View("index");
            }
            return View();
        }

        [HttpGet]
        public ActionResult Search()
        {
            LocationsClient LC = new LocationsClient();
            var loc = LC.findAll().ToList();
            List<SelectListItem> liLoc = new List<SelectListItem>();
            liLoc.Add(new SelectListItem { Text = "--Select Location--", Value = "0" });

            foreach (var m in loc)
            {
                liLoc.Add(new SelectListItem { Text = m.LocName, Value = m.LocId.ToString() });
                ViewBag.Location = liLoc;
            }
            return View();
        }

        [HttpPost]
        public ActionResult Search(FormCollection form)
        {
            SkuClient SC = new SkuClient();
            int locID = Convert.ToInt32(form["Location"]);
           int deptId = Convert.ToInt32(form["Dept"]);
           int catgID = Convert.ToInt32(form["Catg"]);
           int subCatgID = Convert.ToInt32(form["SubCatg"]);

            ViewBag.listSku = SC.SearchByID(locID,deptId,catgID,subCatgID).ToList();

            if (ViewBag.listSku == null)
            {
                ViewBag.ErrorMessage = "No records found";
                return View("index");
            }
           // LocationDropDown();
            return View();
        }

        public void LocationDropDown()
        {
            // LocationsViewModel lvm = new LocationsViewModel();
            LocationsClient LC = new LocationsClient();
            var loc = LC.findAll().ToList();
            List<SelectListItem> liLoc = new List<SelectListItem>();
            liLoc.Add(new SelectListItem { Text = "--Select Location--", Value = "0" });

            foreach (var m in loc)
            {


                liLoc.Add(new SelectListItem { Text = m.LocName, Value = m.LocId.ToString() });
                ViewBag.country = liLoc;

            }
        }
      

        public JsonResult getDepartment(int id)
        {
            LocationsClient LC = new LocationsClient();
           // ViewBag.listDepartment = LC.GetDepartmentsByLoc(id);
            var dept = LC.GetDepartmentsByLoc(id).ToList();
            List<SelectListItem> liDept = new List<SelectListItem>();

            liDept.Add(new SelectListItem { Text = "--Select State--", Value = "0" });
            if (dept != null)
            {
                foreach (var x in dept)
                {
                    liDept.Add(new SelectListItem { Text = x.DeptName, Value = x.DeptId.ToString() });
                }
            }

            return Json(new SelectList(liDept, "Value", "Text", JsonRequestBehavior.AllowGet));
        }

        public JsonResult getSubCatg(int id)
        {
            LocationsClient LC = new LocationsClient();
            var subCtg = LC.SubCatgDeptLoc(id).ToList();
           // var city = obj.tbl_city.Where(x => x.statecode == id).ToList();
            List<SelectListItem> liSubCatg = new List<SelectListItem>();

            liSubCatg.Add(new SelectListItem { Text = "--Select SubCategory--", Value = "0" });
            if (subCtg != null)
            {
                foreach (var l in subCtg)
                {
                    liSubCatg.Add(new SelectListItem { Text = l.SubCatgName, Value = l.SubCatgId.ToString() });

                }
            }

            return Json(new SelectList(liSubCatg, "Value", "Text", JsonRequestBehavior.AllowGet));
        }


        public JsonResult getCatg(int id)
        {
            LocationsClient LC = new LocationsClient();
            var catg = LC.CatgDeptLoc(id).ToList();
            // var city = obj.tbl_city.Where(x => x.statecode == id).ToList();
            List<SelectListItem> liCatg = new List<SelectListItem>();

            liCatg.Add(new SelectListItem { Text = "--Select Category--", Value = "0" });
            if (catg != null)
            {
                foreach (var l in catg)
                {
                    liCatg.Add(new SelectListItem { Text = l.CatgName, Value = l.CatgId.ToString() });

                }
            }

            return Json(new SelectList(liCatg, "Value", "Text", JsonRequestBehavior.AllowGet));
        }



    }
}