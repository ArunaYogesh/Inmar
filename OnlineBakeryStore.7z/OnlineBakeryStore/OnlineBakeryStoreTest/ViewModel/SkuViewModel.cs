﻿using OnlineBakeryStoreTest.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OnlineBakeryStoreTest.ViewModel
{
    public class SkuViewModel
    {
        public SkuData skuDat { get; set; }
    }
}