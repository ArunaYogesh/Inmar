﻿using OnlineBakeryStoreTest.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OnlineBakeryStoreTest.ViewModel
{
    public class UsersViewModel
    {
        public  Users users { get; set; }
    }
}