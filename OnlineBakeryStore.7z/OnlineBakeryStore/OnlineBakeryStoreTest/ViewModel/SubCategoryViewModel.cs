﻿using OnlineBakeryStoreTest.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OnlineBakeryStoreTest.ViewModel
{
    public class SubCategoryViewModel
    {
        public SubCategory subCategory { get; set; }
    }
}