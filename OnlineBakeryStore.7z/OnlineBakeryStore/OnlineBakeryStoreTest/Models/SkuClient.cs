﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Web;

namespace OnlineBakeryStoreTest.Models
{
    public class SkuClient
    {
        //private string Base_URL = "http://localhost:59496/api/";

        private string Base_URL = ConfigurationManager.AppSettings["webApiUrlPath"].ToString();

        public IEnumerable<MySku> GetAll()//GetAllDetails
            {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(Base_URL);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                //client.DefaultRequestHeaders.Add("ContentType", "application/json");

                //This is the key section you were missing    
                /*var plainTextBytes = System.Text.Encoding.UTF8.GetBytes("Aruna:aruna");
                string val = System.Convert.ToBase64String(plainTextBytes);

                client.DefaultRequestHeaders.Add("Authorization", "Basic " + val);*/

                HttpResponseMessage response = client.GetAsync("SkuDetails").Result;

                if (response.IsSuccessStatusCode)
                    return response.Content.ReadAsAsync<IEnumerable<MySku>>().Result;
                return null;
            }
            catch
            {
                return null;
            }
        }

        public IEnumerable<MySku> SearchByID(int locId,int deptId, int catgId, int subId)//GetAllDetails
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(Base_URL);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                //client.DefaultRequestHeaders.Add("ContentType", "application/json");

                //This is the key section you were missing    
                /*var plainTextBytes = System.Text.Encoding.UTF8.GetBytes("Aruna:aruna");
                string val = System.Convert.ToBase64String(plainTextBytes);

                client.DefaultRequestHeaders.Add("Authorization", "Basic " + val);*/

                HttpResponseMessage response = client.GetAsync("SearchData/" + locId + "/department/" + deptId + "/catg/" + catgId + "/subcatg/" + subId).Result;

                if (response.IsSuccessStatusCode)
                    return response.Content.ReadAsAsync<IEnumerable<MySku>>().Result;
                return null;
            }
            catch
            {
                return null;
            }
        }
        public IEnumerable<SkuData> findAll()
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(Base_URL);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                //client.DefaultRequestHeaders.Add("ContentType", "application/json");

                //This is the key section you were missing    
                /*var plainTextBytes = System.Text.Encoding.UTF8.GetBytes("Aruna:aruna");
                string val = System.Convert.ToBase64String(plainTextBytes);

                client.DefaultRequestHeaders.Add("Authorization", "Basic " + val);*/

                HttpResponseMessage response = client.GetAsync("SkuDetails").Result;

                if (response.IsSuccessStatusCode)
                    return response.Content.ReadAsAsync<IEnumerable<SkuData>>().Result;
                return null;
            }
            catch
            {
                return null;
            }
        }

        //public IHttpActionResult GetCustomer(int id) from web api
        public SkuData find(int id)
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(Base_URL);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                /*client.DefaultRequestHeaders.Add("ContentType", "application/json");

                //This is the key section you were missing    
                var plainTextBytes = System.Text.Encoding.UTF8.GetBytes("Aruna:aruna");
                string val = System.Convert.ToBase64String(plainTextBytes);

                client.DefaultRequestHeaders.Add("Authorization", "Basic " + val);*/
                HttpResponseMessage response = client.GetAsync("SkuDetails/" + id).Result;

                if (response.IsSuccessStatusCode)
                    return response.Content.ReadAsAsync<SkuData>().Result;
                return null;
            }
            catch
            {
                return null;
            }
        }

        public bool Create(SkuData sku)
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(Base_URL);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                /*client.DefaultRequestHeaders.Add("ContentType", "application/json");

                //This is the key section you were missing    
                var plainTextBytes = System.Text.Encoding.UTF8.GetBytes("Aruna:aruna");
                string val = System.Convert.ToBase64String(plainTextBytes);
                client.DefaultRequestHeaders.Add("Authorization", "Basic " + val);*/

                HttpResponseMessage response = client.PostAsJsonAsync("SkuDetails", sku).Result;

                if (response.IsSuccessStatusCode)
                {
                    return true;
                }
                else
                {
                    return response.IsSuccessStatusCode;
                }
            }
            catch
            {
                return false;
            }
        }

        public bool Edit(SkuData sku)
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(Base_URL);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = client.PutAsJsonAsync("SkuDetails/" + sku.SkuId, sku).Result;
                return response.IsSuccessStatusCode;
            }
            catch
            {
                return false;
            }
        }

        // public IHttpActionResult DeleteCustomer in web api
        public bool Delete(int id)
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(Base_URL);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = client.DeleteAsync("SkuDetails/" + id).Result;
                return response.IsSuccessStatusCode;
            }
            catch
            {
                return false;
            }
        }
    }
}