﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace OnlineBakeryStoreTest.Models
{
    public class Category
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Display(Name = "Category Id")]
        public int CatgId { get; set; }

        [Display(Name = "Category Name")]
        public string CatgName { get; set; }

        [Display(Name = "Department")]
        public Nullable<int> DeptId { get; set; }
        
    }
}