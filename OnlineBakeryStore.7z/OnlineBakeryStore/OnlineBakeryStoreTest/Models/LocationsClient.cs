﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Net.Http;
using System.Net.Http.Headers;

namespace OnlineBakeryStoreTest.Models
{
    public class LocationsClient
    {
        // private string Base_URL = "http://localhost:59496/api/";

        private string Base_URL = ConfigurationManager.AppSettings["webApiUrlPath"].ToString();

        //public IQueryable<Customer> GetCustomers() in web api
        public IEnumerable<Locations> findAll()
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(Base_URL);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                //client.DefaultRequestHeaders.Add("ContentType", "application/json");

                //This is the key section you were missing    
                /*var plainTextBytes = System.Text.Encoding.UTF8.GetBytes("Aruna:aruna");
                string val = System.Convert.ToBase64String(plainTextBytes);

                client.DefaultRequestHeaders.Add("Authorization", "Basic " + val);*/

                HttpResponseMessage response = client.GetAsync("Location").Result;

                if (response.IsSuccessStatusCode)
                    return response.Content.ReadAsAsync<IEnumerable<Locations>>().Result;
                return null;
            }
            catch
            {
                return null;
            }
        }

        //public IHttpActionResult GetCustomer(int id) from web api
        public Locations find(int id)
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(Base_URL);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                /*client.DefaultRequestHeaders.Add("ContentType", "application/json");

                //This is the key section you were missing    
                var plainTextBytes = System.Text.Encoding.UTF8.GetBytes("Aruna:aruna");
                string val = System.Convert.ToBase64String(plainTextBytes);

                client.DefaultRequestHeaders.Add("Authorization", "Basic " + val);*/
                HttpResponseMessage response = client.GetAsync("Location/" + id).Result;

                if (response.IsSuccessStatusCode)
                    return response.Content.ReadAsAsync<Locations>().Result;
                return null;
            }
            catch
            {
                return null;
            }
        }

        public IEnumerable<LocationNames> GetLocationNames()
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(Base_URL);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

               /* client.DefaultRequestHeaders.Add("ContentType", "application/json");

                //This is the key section you were missing    
                var plainTextBytes = System.Text.Encoding.UTF8.GetBytes("Aruna:aruna");
                string val = System.Convert.ToBase64String(plainTextBytes);

                client.DefaultRequestHeaders.Add("Authorization", "Basic " + val);*/

                HttpResponseMessage response = client.GetAsync("LocationNames").Result;

                if (response.IsSuccessStatusCode)
                    return response.Content.ReadAsAsync<IEnumerable<LocationNames>>().Result;
                return null;
            }
            catch
            {
                return null;
            }
        }

        // public IHttpActionResult PostCustomer(Customer customer) in we api
        public bool Create(Locations location)
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(Base_URL);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                /*client.DefaultRequestHeaders.Add("ContentType", "application/json");

                //This is the key section you were missing    
                var plainTextBytes = System.Text.Encoding.UTF8.GetBytes("Aruna:aruna");
                string val = System.Convert.ToBase64String(plainTextBytes);
                client.DefaultRequestHeaders.Add("Authorization", "Basic " + val);*/

                HttpResponseMessage response = client.PostAsJsonAsync("Location", location).Result;

                if (response.IsSuccessStatusCode)
                {
                    return true;
                }
                else
                {
                    return response.IsSuccessStatusCode;
                }
            }
            catch
            {
                return false;
            }
        }

        public bool Edit(Locations location)
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(Base_URL);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = client.PutAsJsonAsync("Location/" + location.LocId, location).Result;
                return response.IsSuccessStatusCode;
            }
            catch
            {
                return false;
            }
        }

        // public IHttpActionResult DeleteCustomer in web api
        public bool Delete(int id)
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(Base_URL);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = client.DeleteAsync("Location/" + id).Result;
                return response.IsSuccessStatusCode;
            }
            catch
            {
                return false;
            }
        }


        public IEnumerable<MyDept> GetDepartmentsByLoc(int id)
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(Base_URL);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                /* client.DefaultRequestHeaders.Add("ContentType", "application/json");

                 //This is the key section you were missing    
                 var plainTextBytes = System.Text.Encoding.UTF8.GetBytes("Aruna:aruna");
                 string val = System.Convert.ToBase64String(plainTextBytes);

                 client.DefaultRequestHeaders.Add("Authorization", "Basic " + val);*/

                HttpResponseMessage response = client.GetAsync("SearchData/" + id +"/Department").Result;

                if (response.IsSuccessStatusCode)
                    return response.Content.ReadAsAsync<IEnumerable<MyDept>>().Result;
                return null;
            }
            catch
            {
                return null;
            }
        }

        public IEnumerable<CatgData> CatgDeptLoc(int deptId)
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(Base_URL);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                /* client.DefaultRequestHeaders.Add("ContentType", "application/json");

                 //This is the key section you were missing    
                 var plainTextBytes = System.Text.Encoding.UTF8.GetBytes("Aruna:aruna");
                 string val = System.Convert.ToBase64String(plainTextBytes);

                 client.DefaultRequestHeaders.Add("Authorization", "Basic " + val);*/

                HttpResponseMessage response = client.GetAsync("SearchData/" + deptId + "/category").Result;

                if (response.IsSuccessStatusCode)
                    return response.Content.ReadAsAsync<IEnumerable<CatgData>>().Result;
                return null;
            }
            catch
            {
                return null;
            }
        }
        public IEnumerable<SubCatgData> SubCatgDeptLoc(int catgID)
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(Base_URL);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                /* client.DefaultRequestHeaders.Add("ContentType", "application/json");

                 //This is the key section you were missing    
                 var plainTextBytes = System.Text.Encoding.UTF8.GetBytes("Aruna:aruna");
                 string val = System.Convert.ToBase64String(plainTextBytes);

                 client.DefaultRequestHeaders.Add("Authorization", "Basic " + val);*/

                HttpResponseMessage response = client.GetAsync("SearchData/" + catgID + "/subcategory").Result;

                if (response.IsSuccessStatusCode)
                    return response.Content.ReadAsAsync<IEnumerable<SubCatgData>>().Result;
                return null;
            }
            catch
            {
                return null;
            }
        }


    }
}