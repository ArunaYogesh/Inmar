﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace OnlineBakeryStoreTest.Models
{
    public class Departments
    {            
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Display(Name = "Department Id")]
        public int DeptId { get; set; }

        [Display(Name = "Department Name")]
        public string DeptName { get; set; }

        [Display(Name = "Location")]
        public Nullable<int> LocId { get; set; }
       
    }
}