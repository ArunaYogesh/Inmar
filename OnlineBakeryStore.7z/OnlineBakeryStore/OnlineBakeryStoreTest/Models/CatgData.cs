﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OnlineBakeryStoreTest.Models
{
    public class CatgData
    {
            public int CatgId { get; set; }
            public string CatgName { get; set; }
            public string DeptName { get; set; }

           // public string LocName { get; set; }
    }
}