﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace OnlineBakeryStoreTest.Models
{
    public class SubCategory
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Display(Name = "SubCategory Id")]
        public int SubCatgId { get; set; }
        [Display(Name = "SubCategory Name")]
        public string SubCatgName { get; set; }

        [Display(Name = "Category")]
        public Nullable<int> CatgId { get; set; }
    }
}