﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Web;

namespace OnlineBakeryStoreTest.Models
{
    public class SubCategoryClient
    {
        // private string Base_URL = "http://localhost:59496/api/";
        private string Base_URL = ConfigurationManager.AppSettings["webApiUrlPath"].ToString();

        //public IQueryable<Customer> GetCustomers() in web api
        public IEnumerable<SubCategory> findAll()
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(Base_URL);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                //client.DefaultRequestHeaders.Add("ContentType", "application/json");

                //This is the key section you were missing    
                /*var plainTextBytes = System.Text.Encoding.UTF8.GetBytes("Aruna:aruna");
                string val = System.Convert.ToBase64String(plainTextBytes);

                client.DefaultRequestHeaders.Add("Authorization", "Basic " + val);*/

                HttpResponseMessage response = client.GetAsync("SubCategory").Result;

                if (response.IsSuccessStatusCode)
                    return response.Content.ReadAsAsync<IEnumerable<SubCategory>>().Result;
                return null;
            }
            catch
            {
                return null;
            }
        }

        //public IHttpActionResult GetCustomer(int id) from web api
        public SubCategory find(int id)
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(Base_URL);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                /*client.DefaultRequestHeaders.Add("ContentType", "application/json");

                //This is the key section you were missing    
                var plainTextBytes = System.Text.Encoding.UTF8.GetBytes("Aruna:aruna");
                string val = System.Convert.ToBase64String(plainTextBytes);

                client.DefaultRequestHeaders.Add("Authorization", "Basic " + val);*/
                HttpResponseMessage response = client.GetAsync("SubCategory/" + id).Result;

                if (response.IsSuccessStatusCode)
                    return response.Content.ReadAsAsync<SubCategory>().Result;
                return null;
            }
            catch
            {
                return null;
            }
        }

         public bool Create(SubCategory subcategory)
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(Base_URL);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                /*client.DefaultRequestHeaders.Add("ContentType", "application/json");

                //This is the key section you were missing    
                var plainTextBytes = System.Text.Encoding.UTF8.GetBytes("Aruna:aruna");
                string val = System.Convert.ToBase64String(plainTextBytes);
                client.DefaultRequestHeaders.Add("Authorization", "Basic " + val);*/

                HttpResponseMessage response = client.PostAsJsonAsync("SubCategory", subcategory).Result;

                if (response.IsSuccessStatusCode)
                {
                    return true;
                }
                else
                {
                    return response.IsSuccessStatusCode;
                }
            }
            catch
            {
                return false;
            }
        }

        public bool Edit(SubCategory subcategory)
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(Base_URL);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = client.PutAsJsonAsync("SubCategory/" + subcategory.SubCatgId, subcategory).Result;
                return response.IsSuccessStatusCode;
            }
            catch
            {
                return false;
            }
        }

        // public IHttpActionResult DeleteCustomer in web api
        public bool Delete(int id)
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(Base_URL);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = client.DeleteAsync("SubCategory/" + id).Result;
                return response.IsSuccessStatusCode;
            }
            catch
            {
                return false;
            }
        }
    }
}