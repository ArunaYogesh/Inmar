﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace OnlineBakeryStoreTest.Models
{
    public class LocationNames
    {
        [Display(Name="LocationId")]
        public int LocId { get; set; }
        [Display(Name = "LocationName")]
        public string LocNames { get; set; }
    }
}