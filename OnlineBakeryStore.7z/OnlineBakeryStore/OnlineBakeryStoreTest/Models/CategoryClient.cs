﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Web;

namespace OnlineBakeryStoreTest.Models
{
    public class CategoryClient
    {
        //  private string Base_URL = "http://localhost:59496/api/";
        private string Base_URL = ConfigurationManager.AppSettings["webApiUrlPath"].ToString();

        //public IQueryable<Customer> GetCustomers() in web api
        public IEnumerable<Category> findAll()
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(Base_URL);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                //client.DefaultRequestHeaders.Add("ContentType", "application/json");

                //This is the key section you were missing    
                /*var plainTextBytes = System.Text.Encoding.UTF8.GetBytes("Aruna:aruna");
                string val = System.Convert.ToBase64String(plainTextBytes);

                client.DefaultRequestHeaders.Add("Authorization", "Basic " + val);*/

                HttpResponseMessage response = client.GetAsync("Category").Result;

                if (response.IsSuccessStatusCode)
                    return response.Content.ReadAsAsync<IEnumerable<Category>>().Result;
                return null;
            }
            catch
            {
                return null;
            }
        }

        //public IHttpActionResult GetCustomer(int id) from web api
        public Category find(int id)
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(Base_URL);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                /*client.DefaultRequestHeaders.Add("ContentType", "application/json");

                //This is the key section you were missing    
                var plainTextBytes = System.Text.Encoding.UTF8.GetBytes("Aruna:aruna");
                string val = System.Convert.ToBase64String(plainTextBytes);

                client.DefaultRequestHeaders.Add("Authorization", "Basic " + val);*/
                HttpResponseMessage response = client.GetAsync("Category/" + id).Result;

                if (response.IsSuccessStatusCode)
                    return response.Content.ReadAsAsync<Category>().Result;
                return null;
            }
            catch
            {
                return null;
            }
        }

        //public IEnumerable<CutomerDropDown> CustomerDropdown()
        //{
        //    try
        //    {
        //        HttpClient client = new HttpClient();
        //        client.BaseAddress = new Uri(Base_URL);
        //        client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

        //        client.DefaultRequestHeaders.Add("ContentType", "application/json");

        //        //This is the key section you were missing    
        //        var plainTextBytes = System.Text.Encoding.UTF8.GetBytes("Aruna:aruna");
        //        string val = System.Convert.ToBase64String(plainTextBytes);

        //        client.DefaultRequestHeaders.Add("Authorization", "Basic " + val);

        //        HttpResponseMessage response = client.GetAsync("customernames").Result;

        //        if (response.IsSuccessStatusCode)
        //            return response.Content.ReadAsAsync<IEnumerable<CutomerDropDown>>().Result;
        //        return null;
        //    }
        //    catch
        //    {
        //        return null;
        //    }
        //}

        // public IHttpActionResult PostCustomer(Customer customer) in we api
        public bool Create(Category category)
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(Base_URL);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                /*client.DefaultRequestHeaders.Add("ContentType", "application/json");

                //This is the key section you were missing    
                var plainTextBytes = System.Text.Encoding.UTF8.GetBytes("Aruna:aruna");
                string val = System.Convert.ToBase64String(plainTextBytes);
                client.DefaultRequestHeaders.Add("Authorization", "Basic " + val);*/

                HttpResponseMessage response = client.PostAsJsonAsync("Category", category).Result;

                if (response.IsSuccessStatusCode)
                {
                    return true;
                }
                else
                {
                    return response.IsSuccessStatusCode;
                }
            }
            catch
            {
                return false;
            }
        }

        public bool Edit(Category category)
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(Base_URL);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = client.PutAsJsonAsync("Category/" + category.CatgId, category).Result;
                return response.IsSuccessStatusCode;
            }
            catch
            {
                return false;
            }
        }

        // public IHttpActionResult DeleteCustomer in web api
        public bool Delete(int id)
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(Base_URL);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = client.DeleteAsync("Category/" + id).Result;
                return response.IsSuccessStatusCode;
            }
            catch
            {
                return false;
            }
        }
    }
}