﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace OnlineBakeryStoreTest.Models
{
    public class CascadingModel
    {
        public CascadingModel()
        {
            this.Locations = new List<SelectListItem>();
            this.Depts = new List<SelectListItem>();
            this.Catgs = new List<SelectListItem>();
            this.SubCatgs = new List<SelectListItem>();
        }

        public List<SelectListItem> Locations { get; set; }
        public List<SelectListItem> Depts { get; set; }
        public List<SelectListItem> Catgs { get; set; }
        public List<SelectListItem> SubCatgs { get; set; }

        public int LocId { get; set; }
        public int DeptId { get; set; }
        public int CatgId { get; set; }
        public int SubCatgId { get; set; }
    }
}