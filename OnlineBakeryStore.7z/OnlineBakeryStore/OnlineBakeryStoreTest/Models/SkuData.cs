﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace OnlineBakeryStoreTest.Models
{
    public class SkuData
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Display(Name = "Sku Id")]
        public int SkuId { get; set; }

        [Display(Name = "Sku Name")]
        public string SkuName { get; set; }

        [Display(Name = "Location")]
        public Nullable<int> LocId { get; set; }

        [Display(Name = "Department")]
        public Nullable<int> DeptId { get; set; }

        [Display(Name = "Category")]
        public Nullable<int> CatgId { get; set; }

        [Display(Name = "SubCategory")]
        public Nullable<int> SubCatgID { get; set; }
    }
}