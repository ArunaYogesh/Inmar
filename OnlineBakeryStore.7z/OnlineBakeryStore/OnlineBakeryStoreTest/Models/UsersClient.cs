﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Web;

namespace OnlineBakeryStoreTest.Models
{
    public class UsersClient
    {
        // private string Base_URL = "http://localhost:59496/api/";

        private string Base_URL = ConfigurationManager.AppSettings["webApiUrlPath"].ToString();

        //public IHttpActionResult GetCustomer(int id) from web api
        public Users find(string username)
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(Base_URL);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                /*client.DefaultRequestHeaders.Add("ContentType", "application/json");

                //This is the key section you were missing    
                var plainTextBytes = System.Text.Encoding.UTF8.GetBytes("Aruna:aruna");
                string val = System.Convert.ToBase64String(plainTextBytes);

                client.DefaultRequestHeaders.Add("Authorization", "Basic " + val);*/
                HttpResponseMessage response = client.GetAsync("User/" + username).Result;

                if (response.IsSuccessStatusCode)
                    return response.Content.ReadAsAsync<Users>().Result;
                return null;
            }
            catch
            {
                return null;
            }
        }

        public bool Create(Users user)
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(Base_URL);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                /*client.DefaultRequestHeaders.Add("ContentType", "application/json");

                //This is the key section you were missing    
                var plainTextBytes = System.Text.Encoding.UTF8.GetBytes("Aruna:aruna");
                string val = System.Convert.ToBase64String(plainTextBytes);
                client.DefaultRequestHeaders.Add("Authorization", "Basic " + val);*/

                HttpResponseMessage response = client.PostAsJsonAsync("User", user).Result;

                if (response.IsSuccessStatusCode)
                {
                    return true;
                }
                else
                {
                    return response.IsSuccessStatusCode;
                }
            }
            catch
            {
                return false;
            }
        }


    }
}